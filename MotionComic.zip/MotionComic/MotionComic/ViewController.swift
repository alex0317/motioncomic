//
//  ViewController.swift
//  MotionComic
//
//  Created by iOS on 5/19/20.
//  Copyright © 2020 iOS. All rights reserved.
//

import UIKit
import SpriteKit

class ViewController: UIViewController {
    let frameSize = CGSize(width: 640.0, height: 960.0)
    let borderSize: CGFloat = 6.0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let scenes = ParserKit.loadScript(path: "main.ssk")
        let scene = MotionComicScene(scenes, calculateViewPortSize(), frameSize, borderSize)
        if let view = self.view as? SKView {
//            view.showsFPS = true
//            view.showsDrawCount = true
            view.ignoresSiblingOrder = true
            view.preferredFramesPerSecond = 30
            scene.scaleMode = .aspectFill
            view.presentScene(scene)
        }
    }
    
    func calculateViewPortSize() -> CGSize {
        let viewSize = self.view.bounds.size
        let widthRatio = viewSize.width / frameSize.width
        let heightRatio = viewSize.height / frameSize.height
        let ratio = widthRatio < heightRatio ? widthRatio : heightRatio
        
        return CGSize(width: viewSize.width / ratio, height: viewSize.height / ratio)
    }
}

