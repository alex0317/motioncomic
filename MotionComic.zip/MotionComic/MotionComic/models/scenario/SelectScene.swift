//
//  SelectScene.swift
//  MotionComic
//
//  Created by iOS on 5/19/20.
//  Copyright © 2020 iOS. All rights reserved.
//

import UIKit

class SelectScene: BaseScene {
    var color: String = ""
    var font_color: String = ""
    var storage: String = ""
    var target: String = ""
    var name: String = ""
    var text: String = ""
    var x: Int = 0
    var y: Int = 0
    var width: Int = 0
    var height: Int = 0
    var size: Int = 30
    var graphic: String = ""
    var enterimg: String = ""
    var clickse: String = ""
    var enterse: String = ""
    var leavese: String = ""
    var face: String = ""
    var posX: Int = 0
    var posY: Int = 0
    var anchorX: Float = 0.5
    var anchorY: Float = 0.5
    var blur: Int = 0
    
    override func parseScene(line: String) {
        super.parseScene(line: line)
        color = getStringValue(key: "name")
        font_color = getStringValue(key: "name")
        storage = getStringValue(key: "storage")
        target = getStringValue(key: "target")
        name = getStringValue(key: "name")
        text = getStringValue(key: "text")
        x = getIntValue(key: "x")
        y = getIntValue(key: "y")
        width = getIntValue(key: "width")
        height = getIntValue(key: "height")
        size = getIntValue(key: "size", def: 30)
        graphic = getStringValue(key: "graphic")
        enterimg = getStringValue(key: "enterimg")
        clickse = getStringValue(key: "clickse")
        enterse = getStringValue(key: "enterse")
        leavese = getStringValue(key: "leavese")
        face = getStringValue(key: "face")
        posX = getIntValue(key: "posX")
        posY = getIntValue(key: "posY")
        anchorX = getFloatValue(key: "anchorX", def: 0.5)
        anchorY = getFloatValue(key: "anchorY", def: 0.5)
        blur = getIntValue(key: "blur")
    }
}
