//
//  DefaultColorScene.swift
//  MotionComic
//
//  Created by iOS on 5/19/20.
//  Copyright © 2020 iOS. All rights reserved.
//

import UIKit

class DefaultColorScene: BaseScene {
    var color: String = "0xffffff"
    
    override func parseScene(line: String) {
        super.parseScene(line: line)
        color = getStringValue(key: "color")
    }
}
