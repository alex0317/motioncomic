//
//  PlaySoundScene.swift
//  MotionComic
//
//  Created by iOS on 5/19/20.
//  Copyright © 2020 iOS. All rights reserved.
//

import UIKit

class PlaySoundScene: BaseScene {
    var name: String = ""
    var path: String = ""
    var loop: Bool = false
    var volume: Int = 100
    var clear: Bool = false
    var laterTime: Int = 100
    var wait: Bool = false
    
    override func parseScene(line: String) {
        super.parseScene(line: line)
        name = getStringValue(key: "name")
        loop = getBooleanValue(key: "loop")
        volume = getIntValue(key: "volume", def: 100)
        clear = getBooleanValue(key: "clear")
        laterTime = getIntValue(key: "laterTime", def: 100)
        wait = getBooleanValue(key: "wait")
    }
}
