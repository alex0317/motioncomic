//
//  PlayBGMScene.swift
//  MotionComic
//
//  Created by iOS on 5/19/20.
//  Copyright © 2020 iOS. All rights reserved.
//

import UIKit

class PlayBGMScene: PlaySoundScene {
    override func parseScene(line: String) {
        super.parseScene(line: line)
        path = "resource/sound/bgm/\(name)"
    }
}
