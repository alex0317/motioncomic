//
//  CharaScene.swift
//  MotionComic
//
//  Created by iOS on 5/19/20.
//  Copyright © 2020 iOS. All rights reserved.
//

import UIKit

class CharaScene: BaseScene {
    var name = ""
    var path = ""
    var page = "fore"
    var layer = 0
    var wait = true
    var left = 0
    var top = 0
    var width = 0
    var height = 0
    var zindex = 1
    var reflect = 1
    var face = 1
    var storage = ""
    var scale = 100
    var time = 100
    var eye = true
    var mouth = true
    var focus = false
    var posX = 0
    var posY = 0
    var anchorX: Float = 0.5
    var anchorY: Float = 0.0
    var opacity = 100
    var rotate = 0
    var quakeX = 0
    var quakeY = 0
    var quakeT = 0
    var blur = 0
    var mask = false
    var dropTime = 0
    
    override func parseScene(line: String) {
        super.parseScene(line: line)
        name = getStringValue(key: "name")
        path = "resource/character/\(name)"
        page = getStringValue(key: "page", def: "fore")
        layer = getIntValue(key: "layer")
        wait = getBooleanValue(key: "wait", def: true)
        left = getIntValue(key: "left")
        top = getIntValue(key: "top")
        width = getIntValue(key: "width")
        height = getIntValue(key: "height")
        zindex = getIntValue(key: "zindex", def: 1)
        reflect = getIntValue(key: "reflect", def: 1)
        face = getIntValue(key: "face", def: 1)
        storage = getStringValue(key: "storage")
        scale = getIntValue(key: "scale", def: 100)
        time = getIntValue(key: "time", def: 100)
        eye = getBooleanValue(key: "eye", def: true)
        mouth = getBooleanValue(key: "mouth", def: true)
        focus = getBooleanValue(key: "focus")
        posX = getIntValue(key: "posX")
        posY = getIntValue(key: "posY")
        anchorX = getFloatValue(key: "anchorX", def: 0.5)
        anchorY = getFloatValue(key: "anchorY")
        opacity = getIntValue(key: "opacity", def: 100)
        rotate = getIntValue(key: "rotate")
        quakeX = getIntValue(key: "quakeX")
        quakeY = getIntValue(key: "quakeY")
        quakeT = getIntValue(key: "quakeT")
        blur = getIntValue(key: "blur")
        mask = getBooleanValue(key: "mask")
    }

}
