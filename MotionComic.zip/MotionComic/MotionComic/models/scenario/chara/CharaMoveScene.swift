//
//  CharaMoveScene.swift
//  MotionComic
//
//  Created by iOS on 5/19/20.
//  Copyright © 2020 iOS. All rights reserved.
//

import UIKit

class CharaMoveScene: CharaScene {
    var anim = false
    var effect = ""
    var again = 1
    var random = false
    
    override func parseScene(line: String) {
        super.parseScene(line: line)
        anim = getBooleanValue(key: "anim")
        effect = getStringValue(key: "effect")
        again = getIntValue(key: "again", def: 1)
        random = getBooleanValue(key: "random")
    }
}
