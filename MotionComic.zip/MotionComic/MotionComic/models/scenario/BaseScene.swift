//
//  BaseScene.swift
//  MotionComic
//
//  Created by iOS on 5/19/20.
//  Copyright © 2020 iOS. All rights reserved.
//

import UIKit

class BaseScene: NSObject {
    var line: Int
    var valuesMap: [String: String]
    
    public override init() {
        self.line = 0
        self.valuesMap = [ : ]
    }
    
    open func parseScene(line: String) {
        getKeyValuesMap(line: line)
    }

    func getKeyValuesMap(line: String) {
        var content = line.replacingOccurrences(of: "[", with: "")
        content = content.replacingOccurrences(of: "]", with: "")

        let components = content.components(separatedBy: " ")
        for component in components {
            let keyValues = component.components(separatedBy: "=")
            if (keyValues.count != 2) {
                continue
            }
            
            let key = keyValues[0]
            let value = keyValues[1]
            valuesMap[key] = value.replacingOccurrences(of: "\"", with: "")
        }
    }

    func getStringValue(key: String) -> String {
        return getStringValue(key: key, def: "")
    }

    func getStringValue(key: String, def: String) -> String {
        if let val = valuesMap[key] {
            return val
        }
        return def
    }

    func getIntValue(key: String) -> Int {
        return getIntValue(key: key, def: 0)
    }

    func getIntValue(key: String, def: Int) -> Int {
        if let val = valuesMap[key] {
            return Int(val) ?? def
        }
        return def
    }

    func getBooleanValue(key: String) -> Bool {
        return getBooleanValue(key: key, def: false)
    }

    func getBooleanValue(key: String, def: Bool) -> Bool {
        if let val = valuesMap[key] {
            return val == "true"
        }
        return def
    }

    func getFloatValue(key: String) -> Float {
        return getFloatValue(key: key, def: 0.0)
    }

    func getFloatValue(key: String, def: Float) -> Float {
        if let val = valuesMap[key] {
            return Float(val) ?? def
        }
        return def
    }
}
