//
//  SpineHideScene.swift
//  MotionComic
//
//  Created by iOS on 5/19/20.
//  Copyright © 2020 iOS. All rights reserved.
//

import UIKit

class SpineHideScene: BaseScene {
    var name: String = ""
    var face: String = ""
    var reflect: String = ""
    var storage: String = ""
    var time: Int = 1500
    var cross: Bool = false
    var wait: Bool = true
    var mask: Bool = false
    var focus: Bool = false
    var eye: String = ""
    var mouth: String = ""
    
    override func parseScene(line: String) {
        super.parseScene(line: line)
        name = getStringValue(key: "name")
        face = getStringValue(key: "face")
        reflect = getStringValue(key: "reflect")
        storage = getStringValue(key: "storage")
        time = getIntValue(key: "time", def: 1500)
        cross = getBooleanValue(key: "cross")
        wait = getBooleanValue(key: "wait", def: true)
        mask = getBooleanValue(key: "mask")
        focus = getBooleanValue(key: "focus")
        eye = getStringValue(key: "eye")
        mouth = getStringValue(key: "mouth")
    }
}
