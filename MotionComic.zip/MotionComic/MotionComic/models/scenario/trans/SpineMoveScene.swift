//
//  SpineMoveScene.swift
//  MotionComic
//
//  Created by iOS on 5/19/20.
//  Copyright © 2020 iOS. All rights reserved.
//

import UIKit

class SpineMoveScene: SpineScene {
    var left: Int = 0
    var top: Int = 0
    var width: Int = 0
    var height: Int = 0
    var effect:String = ""
    var quakeX: Int = 0
    var quakeY: Int = 0
    var quakeT: Int = 300
    var zindex:Int = 0
    
    override func parseScene(line: String) {
        super.parseScene(line: line)
        left = getIntValue(key: "left")
        top = getIntValue(key: "top")
        width = getIntValue(key: "width")
        height = getIntValue(key: "height")
        effect = getStringValue(key: "effect")
        rotate = getIntValue(key: "rotate")
        quakeX = getIntValue(key: "quakeX")
        quakeY = getIntValue(key: "quakeY")
        quakeT = getIntValue(key: "quakeT", def: 300)
        zindex = getIntValue(key: "zindex")
    }
}
