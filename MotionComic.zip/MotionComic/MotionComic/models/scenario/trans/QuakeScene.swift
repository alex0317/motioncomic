//
//  QuakeScene.swift
//  MotionComic
//
//  Created by iOS on 5/19/20.
//  Copyright © 2020 iOS. All rights reserved.
//

import UIKit

class QuakeScene: BaseScene {
    var count: Int = 2
    var time: Int = 1000
    var x: Int = 1000
    var y: Int = 1000
    var wait: Bool = false
    
    override func parseScene(line: String) {
        super.parseScene(line: line)
        count = getIntValue(key: "count", def: 2)
        time = getIntValue(key: "time", def: 1000)
        x = getIntValue(key: "x", def: 1000)
        y = getIntValue(key: "y", def: 1000)
        wait = getBooleanValue(key: "wait")
    }
}
