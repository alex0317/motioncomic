//
//  SpineScene.swift
//  MotionComic
//
//  Created by iOS on 5/19/20.
//  Copyright © 2020 iOS. All rights reserved.
//

import UIKit

class SpineScene: BaseScene {
    var name: String = ""
    var anim: Bool = false
    var animation: String = ""
    var posX: Int = 0
    var posY: Int = 0
    var scale: Int = 100
    var time: Int = 1000
    var anchorX: Float = 0.5
    var anchorY: Float = 0.0
    var opacity: Int = 100
    var rotate:Int = 0
    var mask: Bool = false
    var blur: Int = 0
    var wait: Bool = true
    var loop: Bool = false
    var laterTime: Int = 0
    var aniLaterTime: Int = 0
    
    override func parseScene(line: String) {
        super.parseScene(line: line)
        name = getStringValue(key: "name")
        anim = getBooleanValue(key: "anim")
        animation = getStringValue(key: "animation")
        posX = getIntValue(key: "posX")
        posY = getIntValue(key: "posY")
        scale = getIntValue(key: "scale", def: 100)
        time = getIntValue(key: "time", def: 1000)
        anchorX = getFloatValue(key: "anchorX", def: 0.5)
        anchorY = getFloatValue(key: "anchorY")
        opacity = getIntValue(key: "opacity", def: 100)
        mask = getBooleanValue(key: "mask")
        blur = getIntValue(key: "blur")
        wait = getBooleanValue(key: "wait", def: true)
        loop = getBooleanValue(key: "loop")
        laterTime = getIntValue(key: "laterTime")
        aniLaterTime = getIntValue(key: "aniLaterTime")
    }
}
