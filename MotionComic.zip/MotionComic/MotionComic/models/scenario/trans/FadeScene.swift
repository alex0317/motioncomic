//
//  FadeScene.swift
//  MotionComic
//
//  Created by iOS on 5/19/20.
//  Copyright © 2020 iOS. All rights reserved.
//

import UIKit

class FadeScene: BaseScene {
    var startRGB: String = ""
    var endRGB: String = ""
    var startAlpha: Int = 0
    var endAlpha: Int = 0
    var time: Int = 0
    var wait: Bool = true
    
    override func parseScene(line: String) {
        super.parseScene(line: line)
        startRGB = getStringValue(key: "start_rgb", def: "0xffffff")
        endRGB = getStringValue(key: "end_rgb", def: "0xffffff")
        startAlpha = getIntValue(key: "start_alpha", def: 100)
        endAlpha = getIntValue(key: "end_alpha", def: 100)
        time = getIntValue(key: "time", def: 1000)
        wait = getBooleanValue(key: "wait", def: true)
    }
}
