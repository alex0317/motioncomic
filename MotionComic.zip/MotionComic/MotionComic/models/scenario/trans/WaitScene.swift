//
//  WaitScene.swift
//  MotionComic
//
//  Created by iOS on 5/19/20.
//  Copyright © 2020 iOS. All rights reserved.
//

import UIKit

class WaitScene: BaseScene {
    var time: Int = 2000
    
    override func parseScene(line: String) {
        super.parseScene(line: line)
        time = getIntValue(key: "time", def: 2000)
    }
}
