//
//  RenderKit.swift
//  MotionComic
//
//  Created by iOS on 5/20/20.
//  Copyright © 2020 iOS. All rights reserved.
//

import UIKit
import SpriteKit

class RenderKit {
    var renderIndex: Int
    var parentNode: SKCropNode
    private var scenes: [BaseScene] = []
    private let clipSize: CGSize
    private let frameSize = CGSize(width: 640.0, height: 960.0)
    private let lock = NSRecursiveLock()
    
    init(_ parentNode: SKCropNode, _ size: CGSize) {
        self.parentNode = parentNode
        self.renderIndex = 0
        self.clipSize = size
    }
    
    func render(_ scenes: [BaseScene]) {
        self.scenes = scenes
        renderNext()
    }

    private func renderNext() {
        if renderIndex >= scenes.count {
            return
        }

        let baseScene = scenes[renderIndex]

        lock.lock()
        renderIndex = renderIndex + 1
        print("Rendering : \(renderIndex)")
        lock.unlock()
        if baseScene is DefaultColorScene {
            renderDefaultScene(baseScene as! DefaultColorScene)
        }
        else if baseScene is FadeScene {
            renderFadeScene(baseScene as! FadeScene)
        }
        else if baseScene is WaitScene {
            renderWaitScene(baseScene as! WaitScene)
        }
        else if baseScene is CharaShowScene {
            renderCharaShowScene(baseScene as! CharaShowScene)
        }
        else if baseScene is CharaMoveScene {
            renderCharaMoveScene(baseScene as! CharaMoveScene)
        }
        else if baseScene is CharaHideScene {
            renderCharaHideScene(baseScene as! CharaHideScene)
        }
        else if baseScene is QuakeScene {
            renderQuakeScene(baseScene as! QuakeScene)
        }
        else if baseScene is SpineMoveScene {
            renderSpineMoveScene(baseScene as! SpineMoveScene)
        }
        else if baseScene is SpineHideScene {
            renderSpineHideScene(baseScene as! SpineHideScene)
        }
        else if baseScene is SpineScene {
            renderSpineScene(baseScene as! SpineScene)
        }
        else if baseScene is SelectScene {
            renderSelectScene(baseScene as! SelectScene)
        }
//        else if baseScene is PlaySeScene {
//            renderPlaySeScene(baseScene as! PlaySeScene)
//        }
//        else if baseScene is PlayVoiceScene {
//            renderPlayVoiceScene(baseScene as! PlayVoiceScene)
//        }
//        else if baseScene is PlayBGMScene {
//            renderPlayBGMScene(baseScene as! PlayBGMScene)
//        }
//        else if baseScene is StopSoundScene {
//            renderStopSoundScene(baseScene as! StopSoundScene)
//        }
        else {
            renderNext()
        }
    }
    
    private func addActionSafely(_ node: SKNode, action: SKAction) {
        addActionSafely(node, action: action, completion: nil)
    }
    
    private func addActionSafely(_ node: SKNode, action: SKAction, completion block: (() -> Void)?) {
        lock.lock()
        if let completionBlock = block {
            node.run(action, completion: completionBlock)
        }
        else {
            node.run(action)
        }
        lock.unlock()
    }
    
    private func addNodeSafely(_ node: SKNode) {
        addNodeSafely(node, withAction: nil)
    }
    
    private func addNodeSafely(_ node: SKNode, withAction action: SKAction?) {
        addNodeSafely(node, withAction: action, completion: nil)
    }
    
    private func addNodeSafely(_ node: SKNode, withAction action: SKAction?, completion block: (() -> Void)?) {
        lock.lock()
        parentNode.addChild(node)
        if let addAction = action {
            addActionSafely(node, action: addAction, completion: block)
        }
        lock.unlock()
    }
    
    private func removeNodeSafely(_ node: SKNode) {
        lock.lock()
        print("Removing \(String(describing: node.name))")
        node.removeAllActions()
        node.removeFromParent()
        lock.unlock()
    }
    
    private func durationSeconds(_ time: Int) -> Double {
        if (Float(time) > 0.03) {
            return Double(time) / 1000.0
        }
        return 0.03
    }
    
    private func waitTime(_ time: Int) {
        Thread.sleep(forTimeInterval: TimeInterval(durationSeconds(time)))
    }
    
    private func renderDefaultScene(_ scene: DefaultColorScene) {
        lock.lock()
        if let previousNode = parentNode.childNode(withName: "defaultColor") {
            removeNodeSafely(previousNode)
        }
        lock.unlock()

        //
        // Draw Rect
        //
        
        let color = ColorUtil.convertHextToSKColor(scene.color)
        let rectNode = SKSpriteNode(color: color, size: clipSize)
        rectNode.position = CGPoint(x: 0, y: 0)
        rectNode.name = "defaultColor"
        addNodeSafely(rectNode)
        
        Thread.detachNewThread {
            self.renderNext()
        }
    }
    
    private func renderFadeScene(_ scene: FadeScene) {
        var sColor = ColorUtil.convertHextToSKColor(scene.startRGB)
        sColor = sColor.withAlphaComponent(CGFloat(Float(scene.startAlpha) / 100.0))
        var eColor = ColorUtil.convertHextToSKColor(scene.endRGB)
        eColor = eColor.withAlphaComponent(CGFloat(Float(scene.endAlpha) / 100.0))
    
        lock.lock()
        if let previousNode = parentNode.childNode(withName: "fade") {
            removeNodeSafely(previousNode)
        }
        lock.unlock()
        
        let rectNode = SKSpriteNode(color: sColor, size: clipSize)
        rectNode.position = CGPoint(x: 0, y: 0)
        rectNode.name = "fade"
        
        let duration = durationSeconds(scene.time)
        let action = SKAction.colorize(with: eColor, colorBlendFactor: 0, duration: duration)
        addNodeSafely(rectNode, withAction: action) {
            rectNode.color = eColor
        }
        
        Thread.detachNewThread {
            if (scene.wait) {
                self.waitTime(scene.time)
            }
            self.renderNext()
        }
    }
    
    private func renderWaitScene(_ scene: WaitScene) {
        print("Rendering wait scene")
        waitTime(scene.time)
        renderNext()
    }
 
    private func getTextureNode(name: String, posX: Int, posY: Int, scale: Int, opacity: Int) -> SKSpriteNode {
        let texture = SKTexture(imageNamed: name)
        let realScale = CGFloat(scale) / 100.0
        let centerPoint = CGPoint(x: CGFloat(posX) - frameSize.width / 2.0, y: CGFloat(posY) - frameSize.height / 2.0)
        let textureNode = SKSpriteNode(texture: texture)
        textureNode.position = centerPoint
        textureNode.setScale(realScale)
        textureNode.alpha = CGFloat(opacity) / 100.0
        textureNode.name = name
        return textureNode
    }
    
    private func getCharacterNode(_ scene: CharaScene) -> SKSpriteNode {
        return getTextureNode(name: scene.name, posX: scene.posX, posY: scene.posY, scale: scene.scale, opacity: scene.opacity)
    }
    
    private func renderCharaShowScene(_ scene: CharaShowScene) {
        let textureNode = getCharacterNode(scene)
        if (scene.time <= 0) {
            addNodeSafely(textureNode)
        }
        else {
            textureNode.alpha = 0.0
            let action = SKAction.fadeAlpha(to: CGFloat(scene.opacity) / 100.0, duration: durationSeconds(scene.time))
            addNodeSafely(textureNode, withAction: action)
        }
        
        Thread.detachNewThread {
            if (scene.wait) {
                self.waitTime(scene.time)
            }
            self.renderNext()
        }
    }

    private func renderCharaMoveScene(_ scene: CharaMoveScene) {
        lock.lock()
        guard let charaNode = parentNode.childNode(withName: scene.name) else {
            lock.unlock()
            Thread.detachNewThread {
                self.renderNext()
            }
            return
        }
        lock.unlock()

        var groupActions = [SKAction]()
        let duration = durationSeconds(scene.time)

        if (scene.posX != 0 || scene.posY != 0) {
            let targetPoint = CGPoint(x: charaNode.position.x + CGFloat(scene.posX),
                                      y: charaNode.position.y + CGFloat(scene.posY))
            groupActions.append(SKAction.move(to: targetPoint, duration: duration))
        }
        if (Int(charaNode.xScale * 100) != scene.scale) {
            groupActions.append(SKAction.scale(to: CGFloat(scene.scale) / 100.0, duration: duration))
        }
        if (Int(charaNode.alpha * 100) != scene.opacity) {
            groupActions.append(SKAction.fadeAlpha(to: CGFloat(scene.opacity) / 100.0, duration: duration))
        }
            
        if (groupActions.count > 0) {
            addActionSafely(charaNode, action: SKAction.group(groupActions))
        }

        Thread.detachNewThread {
            if (scene.wait) {
                self.waitTime(scene.time)
            }
            self.renderNext()
        }
    }

    private func renderCharaHideScene(_ scene: CharaHideScene) {
        lock.lock()
        guard let charaNode = parentNode.childNode(withName: scene.name) else {
            lock.unlock()
            Thread.detachNewThread {
                self.renderNext()
            }
            return
        }
        lock.unlock()
        
        if (scene.time <= 0) {
            removeNodeSafely(charaNode)
        }
        else {
            addActionSafely(charaNode, action: SKAction.fadeAlpha(to: 0.0, duration: durationSeconds(scene.time))) {
                self.removeNodeSafely(charaNode)
            }
        }
        
        Thread.detachNewThread {
            if (scene.wait) {
                self.waitTime(scene.time)
            }
            self.renderNext()
        }
    }

    private func renderQuakeScene(_ scene: QuakeScene) {
        if (scene.time == 0) {
            renderNext()
            return
        }

        let initialPoint = parentNode.position
        var amplitudeX = CGFloat(scene.x)
        var amplitudeY = CGFloat(scene.y)
        var quakeActions = [SKAction]()
        for index in 1...scene.count * 2 {
            if index % 2 == 1 {
                amplitudeX = (-1) * CGFloat(scene.x)
                amplitudeY = (-1) * CGFloat(scene.y)
            }
            let newX = initialPoint.x + amplitudeX
            let newY = initialPoint.y + amplitudeY
            let action = SKAction.move(to: CGPoint(x: newX, y: newY), duration: durationSeconds(scene.time / (scene.count * 2)))
            quakeActions.append(action)
        }
        let quakeAction = SKAction.sequence(quakeActions)
        lock.lock()
        parentNode.run(quakeAction) {
            self.lock.lock()
            self.parentNode.position = initialPoint
            self.parentNode.removeAllActions()
            self.lock.unlock()
        }
        lock.unlock()
        
        Thread.detachNewThread {
            if (scene.wait) {
                self.waitTime(scene.time)
            }
            self.renderNext()
        }
    }

    private func renderSpineScene(_ scene: SpineScene) {
//        Gdx.app.postRunnable {
//            val spineActor = SpineActor(scene.name, scene.scale / 100f,
//                scene.posX.toFloat(), scene.posY.toFloat(),scene.opacity / 100f,
//                scene.loop, scene.rotate.toFloat(), scene.blur.toFloat(), renderView)
//
//            addActorSafely(spineActor)
//            val runnable = Runnable {
//                if (scene.wait) {
//                    spineActor.state.addListener(object : AnimationState.AnimationStateListener {
//                        override fun event(entry: AnimationState.TrackEntry?, event: Event?) {
//                        }
//
//                        override fun complete(entry: AnimationState.TrackEntry?) {
//                            renderNext()
//                        }
//
//                        override fun start(entry: AnimationState.TrackEntry?) {
//                        }
//
//                        override fun end(entry: AnimationState.TrackEntry?) {
//                        }
//
//                        override fun interrupt(entry: AnimationState.TrackEntry?) {
//                        }
//
//                        override fun dispose(entry: AnimationState.TrackEntry?) {
//                        }
//                    })
//                }
//                else {
//                    renderNext()
//                }
//            }
//            val thread = Thread(runnable, "render_next")
//            thread.start()
//        }
        Thread.detachNewThread {
            if (scene.wait) {
                self.waitTime(scene.time)
            }
            self.renderNext()
        }
    }

    private func renderSpineMoveScene(_ scene: SpineMoveScene) {
//        var spineActor: SpineActor? = null
//        lock.lock()
//        for (actor in stage.actors) {
//            if (actor is SpineActor) {
//                if (actor.drawId == scene.name) {
//                    spineActor = actor
//                    break
//                }
//            }
//        }
//        lock.unlock()
//
//        if (spineActor == null) {
//            renderNext()
//            return
//        }
//
//        if (scene.time == 0) {
//            Gdx.app.postRunnable {
//                spineActor.setValueWithScene(scene)
//            }
//            renderNext()
//            return
//        }
//
//        val parallelAction = ParallelAction()
//        val duration = durationSeconds(scene.time)
//        if (scene.posX != 0 || scene.posY != 0) {
//            parallelAction.addAction(Actions.moveTo(spineActor.x + scene.posX.toFloat(),
//            spineActor.y + scene.posY.toFloat(), duration))
//        }
//        if ((spineActor.initScale * 100).toInt() != scene.scale) {
//            parallelAction.addAction(Actions.scaleTo(scene.scale / 100f, scene.scale / 100f,
//            duration))
//        }
//        if ((spineActor.color.a * 100).toInt() != scene.opacity) {
//            parallelAction.addAction(Actions.sequence(Actions.alpha(scene.opacity / 100f, duration)))
//        }
//        if ((spineActor.rotation).toInt() != scene.rotate) {
//            parallelAction.addAction(Actions.rotateTo(scene.rotate.toFloat(), duration))
//        }
//
//        Gdx.app.postRunnable {
//            lock.lock()
//            spineActor.addAction(parallelAction)
//            lock.unlock()
//        }
//
//        if (scene.wait) {
//            waitTime(scene.time)
//        }
//        renderNext()
        Thread.detachNewThread {
            if (scene.wait) {
                self.waitTime(scene.time)
            }
            self.renderNext()
        }
    }

    private func renderSpineHideScene(_ scene: SpineHideScene) {
//        var spineActor: SpineActor? = null
//        lock.lock()
//        for (actor in stage.actors) {
//            if (actor is SpineActor && actor.drawId == scene.name) {
//                spineActor = actor
//                break
//            }
//        }
//        lock.unlock()
//
//        if (spineActor == null) {
//            renderNext()
//            return
//        }
//
//        Gdx.app.postRunnable {
//            removeActorSafely(spineActor)
//        }
//        renderNext()
//        return
        Thread.detachNewThread {
            if (scene.wait) {
                self.waitTime(scene.time)
            }
            self.renderNext()
        }
    }

    private func renderSelectScene(_ scene: SelectScene) {
        let textureNode = getTextureNode(name: "select_bar.png", posX: scene.posX, posY: scene.posY, scale: 100, opacity: 100)
        addNodeSafely(textureNode)
        
        Thread.detachNewThread {
            self.renderNext()
        }
    }
    
    private func renderPlaySeScene(_ scene: PlaySeScene) {
        addMusic(scene)
    }

    private func renderPlayVoiceScene(_ scene: PlayVoiceScene) {
        addMusic(scene)
    }

    private func renderPlayBGMScene(_ scene: PlayBGMScene) {
        addMusic(scene)
    }

    private func renderStopSoundScene(_ scene: StopSoundScene) {
        removeMusic(scene.name)
    }
    
    private func addMusic(_ scene: PlaySoundScene) {
        if (scene.laterTime > 0) {
            waitTime(scene.laterTime)
        }
        let audioNode = SKAudioNode(fileNamed: scene.name)
        audioNode.autoplayLooped = scene.loop
        audioNode.name = scene.name
        let runBlock = SKAction.run {
            audioNode.run(SKAction.play())
        }
        addNodeSafely(audioNode, withAction: runBlock)
        
//        if !scene.loop {
//            lock.lock()
//            let soundLength = FileUtil.getDurationOfAudio(path: scene.name)
//            lock.unlock()
//            Thread.detachNewThread {
//                Thread.sleep(forTimeInterval: soundLength)
//                self.removeNodeSafely(audioNode)
//            }
//        }
        
        Thread.detachNewThread {
            self.renderNext()
        }
    }
    
    private func removeMusic(_ name: String) {
        lock.lock()
        guard let audioNode = parentNode.childNode(withName: name) else {
            lock.unlock()
            Thread.detachNewThread {
                self.renderNext()
            }
            return
        }
        lock.unlock()
        
        removeNodeSafely(audioNode)
        
        Thread.detachNewThread {
            self.renderNext()
        }
    }
}
