//
//  ParserKit.swift
//  MotionComic
//
//  Created by iOS on 5/19/20.
//  Copyright © 2020 iOS. All rights reserved.
//

import UIKit

class ParserKit: NSObject {
    class func loadScript(path: String) -> [BaseScene] {
        var scenes = [BaseScene]()
        guard let path = Bundle.main.path(forResource: "main", ofType: "ssk") else {
            return scenes
        }
        
        let fm = FileManager()
        let exists = fm.fileExists(atPath: path)
        var contentAsString: String? = nil
        if(exists) {
            contentAsString = String(data: fm.contents(atPath: path)!, encoding: String.Encoding.utf8)
        }
        
        guard let content = contentAsString else {
            return scenes
        }
        
        let lines = content.components(separatedBy: "\n")

        for line in lines {
            var scene: BaseScene? = nil
            guard let type = parseTypeFromLine(line: line) else {
                continue
            }
            
            switch type {
            case "defaultColor":
                scene = DefaultColorScene()
                break
            case "fade":
                scene = FadeScene()
                break
            case "wait":
                scene = WaitScene()
                break
            case "playse":
                scene = PlaySeScene()
                break
            case "playvoice":
                scene = PlayVoiceScene()
                break
            case "playbgm":
                scene = PlayBGMScene()
                break
            case "stopse":
                scene = StopSoundScene()
                break
            case "stopbgm":
                scene = StopSoundScene()
                break
            case "chara_show":
                scene = CharaShowScene()
                break
            case "chara_move":
                scene = CharaMoveScene()
                break
            case "chara_hide":
                scene = CharaHideScene()
                break
            case "quake":
                scene = QuakeScene()
                break
            case "spine_hide":
                scene = SpineHideScene()
                break
            case "spine_move":
                scene = SpineMoveScene()
                break
            case "spine":
                scene = SpineScene()
                break
            case "select":
                scene = SelectScene()
                break
            default:
                break
            }
            
            guard let validScene = scene else {
                continue
            }
            validScene.parseScene(line: line)
            scenes.append(validScene)
        }
        
        return scenes
    }
    
    private class func parseTypeFromLine(line: String) -> String? {
        if (line.trimmingCharacters(in: .whitespaces).isEmpty) {
            return nil
        }
    
        var content = line.replacingOccurrences(of: "[", with: "")
        content = content.replacingOccurrences(of: "]", with: "")
    
        let components = content.components(separatedBy: " ")
        return components[0]
    }
}
