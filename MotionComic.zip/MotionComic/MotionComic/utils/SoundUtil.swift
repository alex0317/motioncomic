//
//  SoundUtil.swift
//  MotionComic
//
//  Created by iOS on 5/20/20.
//  Copyright © 2020 iOS. All rights reserved.
//

import UIKit

class SoundUtil: NSObject {
    class func playSound(path: String) {
    }
}
