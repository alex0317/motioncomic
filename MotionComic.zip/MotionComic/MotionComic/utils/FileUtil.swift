//
//  FileUtil.swift
//  MotionComic
//
//  Created by iOS on 5/19/20.
//  Copyright © 2020 iOS. All rights reserved.
//

import UIKit
import AVFoundation
import CoreMedia

class FileUtil: NSObject {
    class func getDurationOfAudio(path: String) -> Double {
        guard let url = Bundle.main.url(forResource: path, withExtension: "") else {
            return 0.0
        }
        let audioAsset = AVURLAsset.init(url: url, options: nil)
        let audioDuration = audioAsset.duration
        let audioDurationSeconds = CMTimeGetSeconds(audioDuration)
        return audioDurationSeconds
    }
}
