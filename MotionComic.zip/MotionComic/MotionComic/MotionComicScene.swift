//
//  MotionComicScene.swift
//  MotionComic
//
//  Created by iOS on 5/19/20.
//  Copyright © 2020 iOS. All rights reserved.
//

import UIKit
import SpriteKit

class MotionComicScene: SKScene {
    var scenes: [BaseScene]
    let borderSize: CGFloat
    let frameSize: CGSize
    let clipSize: CGSize
    let lock = NSRecursiveLock()
    let cropNode: SKCropNode = SKCropNode()
    
    init(_ renderScenes: [BaseScene], _ size: CGSize, _ frameSize: CGSize, _ borderSize: CGFloat) {
        scenes = renderScenes
        self.frameSize = frameSize
        self.borderSize = borderSize
        self.clipSize = CGSize(width: frameSize.width - borderSize * 2.0, height: frameSize.height - borderSize * 2.0)
        super.init(size: size)
    }
    
    required init?(coder aDecoder: NSCoder) {
        scenes = [BaseScene]()
        self.frameSize = CGSize()
        self.borderSize = 0.0
        self.clipSize = CGSize()
        super.init(coder: aDecoder)
    }
    
    override func didMove(to view: SKView) {
        
        //
        // Set background color
        //
        
        backgroundColor = SKColor.black
        
        //
        // Draw bordered rect
        //
        
        let shapeNode = SKShapeNode(rectOf: CGSize(width: frameSize.width - borderSize, height: frameSize.height - borderSize))
        shapeNode.fillColor = SKColor.white
        shapeNode.strokeColor = .blue
        shapeNode.lineWidth = borderSize
        shapeNode.position = CGPoint(x: self.frame.midX, y: self.frame.midY)
        self.addChild(shapeNode)
        
        //
        // Add animation
        //
        
        cropNode.maskNode = SKSpriteNode(color: SKColor.black, size: clipSize)
        cropNode.position = CGPoint(x: frame.midX, y: frame.midY)
        self.addChild(cropNode)

        let renderKit = RenderKit(cropNode, clipSize)
        renderKit.render(scenes)
        
        // {{ Test begin
//        SoundUtil.playSound(path: "se_2600_学校予鈴キーンコーンカーンコーン.mp3")
//        Thread.detachNewThread {
//
//        }

//        let audioNode = SKAudioNode(fileNamed: "se_2600_学校予鈴キーンコーンカーンコーン.mp3")
//        audioNode.autoplayLooped = true
//        audioNode.name = "se_2600_学校予鈴キーンコーンカーンコーン.mp3"
//        let runBlock = SKAction.run {
//            audioNode.run(SKAction.play())
//        }
//        cropNode.addChild(audioNode)
//        cropNode.run(runBlock)
        
//        let rectNode = SKSpriteNode(color: SKColor.red, size: CGSize(width: 320, height: 480))
//        rectNode.position = CGPoint(x: 0, y: 0)
//        cropNode.addChild(rectNode)
//        let colorAction = SKAction.colorize(with: .blue, colorBlendFactor: 0, duration: 5)
//        rectNode.run(colorAction) {
//            rectNode.color = .blue
//        }
        
//        let textureNode = SKSpriteNode(texture: SKTexture(imageNamed: "01コマ目_01"))
//        textureNode.position = CGPoint(x: 0, y: 0)
//        textureNode.name = "test"
//        cropNode.addChild(textureNode)
//        Thread.detachNewThread {
//            Thread.sleep(forTimeInterval: 3.0)
//            let removeNode = self.cropNode.childNode(withName: "test")
//            removeNode?.removeAllActions()
//            removeNode?.removeFromParent()
//        }
//        let fadeAction = SKAction.fadeAlpha(to: 0.4, duration: 1.5)
//        NSLog("Action Started")
//        textureNode.run(fadeAction) {
//            NSLog("Action Completed")
//            self.lock.lock()
//            let removeNode = self.cropNode.childNode(withName: "test")
//            removeNode?.removeAllActions()
//            removeNode?.removeFromParent()
//            self.cropNode.removeAllChildren()
//            self.lock.unlock()
//        }
//        let moveAction = SKAction.move(to: CGPoint(x: 100, y: 0), duration: 5)
//        moveAction.timingMode = .easeInEaseOut
//        textureNode.run(moveAction)
//        Thread.detachNewThread {
//            Thread.sleep(forTimeInterval: 6)
//            let removeNode = self.cropNode.childNode(withName: "test")
//            self.lock.lock()
//            removeNode?.removeAllActions()
//            removeNode?.removeFromParent()
//            self.lock.unlock()
//        }
        // Test End }}
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        let touch: UITouch = touches.first!
        let location = touch.location(in: cropNode)
        let nodes = self.nodes(at: location)
        
        for node in nodes {
            if node.name == "select" {
                break
            }
        }
    }
}
